#include "CryptShift.h"

using namespace std;
using json = nlohmann::json;

CryptShift::CryptShift()
{
	this->algot = "шифр перестановки";
	this->encrypt["alg_type"] = this->algot;
	this->encrypt["text"] = "";
	this->key["alg_type"] = this->algot;
	this->key["key"] = "";
	this->key_size = 10;
}
/////////////////////////////////////////////////////////////////////////////////////////
void CryptShift::Crypt() {
	json tmp = this->key["key"];
	json dkey;
	
	for (auto i = 0; i < static_cast<int>(tmp.size()); i++) dkey[to_string(tmp[i][1])] = tmp[i][0];

	string ctext = "";
	int tsize = this->text.size();
	int hsize = tsize / this->key_size + ((tsize % this->key_size != 0)? 1: 0);

	char** Arr = new char* [this->key_size];
	for (int i = 0; i < this->key_size; i++)
		Arr[i] = new char[hsize];

	auto it = this->text.begin();

	for (int i = 0; i < hsize; i++)
	{
		for (int j = 0; j < this->key_size; j++)
		{
			if (it != this->text.end()) {
				Arr[j][i] = *it;
				++it;
			} else Arr[j][i] = '-';
		}
	}

	for (int i = 0; i < this->key_size; i++)
	{
		for (int j = 0; j < hsize; j++)
		{
			ctext += Arr[dkey[to_string(i)]][j];
		}
	}
	this->encrypt["text"] = ctext;
}
/////////////////////////////////////////////////////////////////////////////////////////
void CryptShift::DeCrypt() {
	json tmp = this->key["key"];
	json dkey;

	for (auto i = 0; i < static_cast<int>(tmp.size()); i++) dkey[to_string(tmp[i][0])] = tmp[i][1];

	string detext = "";
	auto ctext = this->encrypt["text"].get<string>();
	int tsize = ctext.size();
	int hsize = tsize / dkey.size() + ((tsize % dkey.size() != 0) ? 1 : 0);

	char** Arr = new char* [dkey.size()];
	for (auto i = 0; i < static_cast<int>(dkey.size()); i++)
		Arr[i] = new char[hsize];

	auto it = ctext.begin();

	for (auto i = 0; i < static_cast<int>(dkey.size()); i++)
	{
		for (auto j = 0; j < hsize; j++)
		{
			if (it != ctext.end()) {
				Arr[i][j] = *it;
				++it;
			}
			else Arr[i][j] = '-';
		}
	}

	for (auto i = 0; i < hsize; i++)
	{
		for (auto j = 0; j < static_cast<int>(dkey.size()); j++)
		{
			detext += Arr[dkey[to_string(j)]][i];
		}
	}

	int countd = 0;
	for (auto rit = detext.crbegin(); rit != detext.crbegin() + static_cast<int>(dkey.size()); ++rit){
		if (*rit == '-') countd++;
		else break;
	}
	detext.erase(detext.size() - countd);
	
	this->text = detext;
}
/////////////////////////////////////////////////////////////////////////////////////////
void CryptShift::KeyGeneration() {
	json result;
	json tkey;
	for (auto i = 0; i < this->key_size; i++) {
		tkey.push_back(i);
	}
	for (auto i = 0; i < this->key_size; i++) {
		int rval = int((rand() % (this->key_size - i)));
		json tmp = { i, tkey[rval] };
		tkey.erase(rval);
		result.push_back(tmp);
	}
	this->key["key"] = result;
}