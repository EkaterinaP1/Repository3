#pragma once
#include "ACrypt.h"
#include "json.hpp"
#include <string>
#include <fstream>
#include <iostream>

class CryptChange : public ACrypt
{
public:
	CryptChange();

	void KeyGeneration() override;
	void Crypt() override;
	void DeCrypt() override;
};


