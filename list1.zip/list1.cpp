﻿#include <iostream> 
#include <string> 
#include <stdio.h>
#include <fstream> 
#include "list.h" 

int main()
{
	setlocale(LC_ALL, "RUSSIAN");
	list my_list_1;

	my_list_1.add("value 0");
	my_list_1.add("value 1");
	my_list_1.add("value 2");
	my_list_1.add("value 3");
	my_list_1.add("value 4");
	my_list_1.get_item_by_index(3);
	my_list_1.print_all();
	my_list_1.remove(3);
	my_list_1.print_all();
	my_list_1.add_index(2, "value 10");
	my_list_1.print_all();
    my_list_1.remove_all();
	my_list_1.print_all();

	
	return 0;
}