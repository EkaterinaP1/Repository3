﻿#include <iostream> 
#include <string> 
#include <fstream> 
#include "list.h" 

int main()
{
	setlocale(LC_ALL, "RUSSIAN");
	list my_list_1;
	my_list_1.add("value 1");
	my_list_1.add("value 2");
	my_list_1.add("value 3");
	my_list_1.add("value 4");
	my_list_1.print();
	my_list_1.find_print(3);
	my_list_1.remove(2);
	my_list_1.print();
	my_list_1.add_index(2, "value 5");
	my_list_1.print();
	my_list_1.remove_all();
	my_list_1.print();
	return 0;
}