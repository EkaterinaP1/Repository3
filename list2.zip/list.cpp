#include "list.h" 
#include <ostream> 
#include <iostream> 
#include <math.h> 
using namespace std;

list_elem::list_elem(std::string new_data, list_elem* new_prev = nullptr, list_elem* new_next = nullptr)
{
	this->data = new_data;
	this->next = new_next;
	this->prev = new_prev;
}

list_elem::~list_elem()
{
	this->next = nullptr;
	this->prev = nullptr;
}

list::list() {
	this->head = nullptr;
	this->tail = nullptr;
	this->count = 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
void list::add(std::string new_data) {  //�������� �������

	if (head == nullptr && tail == nullptr) {
		auto new_elem = new list_elem(new_data);
		this->head = new_elem;
		this->tail = new_elem;
	}
	else {
		auto new_elem = new list_elem(new_data, this->tail);
		this->tail->next = new_elem;
		this->tail = new_elem;
	}
	this->count++;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
void list::add_index(int index, std::string new_data) { //�������� ������� � ����� ��� ��������
	if ((this->head != nullptr) and (index <= this->count - 1)) {
		auto el = get_item_by_index(index);
		auto new_elem = new list_elem(new_data, el->prev, el);
		el->prev->next = new_elem;
		el->prev = new_elem;
	}
	else
	{
		printf("No values in list!");
		return;
	}

}

bool list::remove(int index)

{
	if ((this->head != nullptr) and (index <= this->count - 1)) {
		if (index == 0) {
			auto tmp = this->head;
			if (this->head->next == nullptr) {
				this->head = nullptr;
				this->tail = nullptr;
			}
			else this->head = this->head->next;
			delete tmp;
			tmp = nullptr;
			this->count--;
			/*this->head->prev = nullptr;*/
			return true;
		}

		auto el = get_item_by_index(index);

		if (this->count - 1 == index) {
			el->prev->next = nullptr;
			this->tail = el->prev;
		}
		else {
			el->prev->next = el->next;
			el->next->prev = el->prev;
		}
		delete el;
		el = nullptr;
		this->count--;
		return true;
	}
	else
	{
		printf("No values in list!");
		return true;
	}
}

bool list::remove_all() {
	if (this->head != nullptr) {
		while (this->head->next != nullptr)
		{
			auto tmp = this->head; // ������� ��������� ������� 
			this->head = this->head->next; // ����������� ��� ��������� �� ��������� 
			this->head->prev = nullptr;
			delete tmp; // � ������� ��� 
			tmp = nullptr;
			this->count--;
		}
		delete this->head;
		this->head = nullptr;
		this->tail = nullptr;
		this->count--;
		return true;
	}
	else
	{
		printf("No values in list!");
		return true;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
list_elem* list::get_item_by_index(int idx) {
	if (this->head != nullptr) {
		auto el = this->head;
		int i = 0;
		while (i < idx)
		{
			el = el->next;
			i++;
		}
		return el;
	}
	else
	{
		printf("No values in list!");
		return nullptr;
	}
}



void list::print_all()
{
	if (this->head != nullptr) {
		auto el = this->head;
		while (el->next != nullptr) {
			cout << el->data << "\n";
			el = el->next;
		}
		cout << el->data << "\n\n";
	}
	else
	{
		printf("No values in list!\n");
	}
	return;
}
